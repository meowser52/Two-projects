pyQuill plain text editor and keyboard trainning
=================
First project in **Python practice** cource.

**Table of Contents**

- [Gallery](#gallery)
- [Features](#features)
- [Installing](#installing)
- [Customization](#customization)
- [Contact](#contact)

# Features
* Basic text editing: select, cut, copy, paste
* Open files, save files, print files
* Standard keyboard shortcuts support
* Keyboard Training with Statistics on matplotlib and features: task texts from wikipedia, words count, timer, erros made, save/clear data to JSON

# Installing
Clone this repository and install requirements (pyQt5, wikipedia, matplotlib required)
```
git clone https://github.com/dm1trykrylov/pyQuill.git && cd pyQuill && git checkout dev
pip install -r requirements.txt
```

Run pyQuill
`python3 main.py`

# Customization
It's easy to design your own themes using `settings.json`.
* Change `default_font` field to set another font
* Change `theme` to dark to use default dark theme or
* set `use_default_theme` to __true__ and provide path to your stylesheet in `stylesheet`

