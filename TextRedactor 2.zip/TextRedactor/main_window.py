from PyQt5.QtGui import QFont, QKeySequence

from PyQt5.QtWidgets import (QApplication,  QDialog, QFileDialog, QLabel, QMainWindow, QMessageBox, QPlainTextEdit, QToolBar, QStatusBar,
                             QVBoxLayout, QWidget, QShortcut, QDialog, QLineEdit, QPushButton, QDialogButtonBox, QHBoxLayout, QGridLayout, QLayout)

from PyQt5.QtCore import (QSize, QFile, QTextStream, Qt)
from PyQt5.QtPrintSupport import QPrintDialog
from PyQt5.QtCore import QTimer
import wikipedia
import time
import random
import traceback
from pathlib import Path
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QDialog, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas


import os

from contextlib import contextmanager

from utility import *

import json
import qdarktheme

class MainWindow(QMainWindow):

    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        self.training_active = False
        self.sample_text = ''
        self.correct_input = ""

        # Open configuration file
        config_file = open('settings.json')
        config = json.load(config_file)

        self.error_history = 0  # История ошибок
        # Set theme
        if config['use_default_theme'] == True:
            self.toggle_theme_default(config['theme'])
        else:
            self.toggle_theme_custom(config['stylesheet'])

        # Setup the QTextEdit editor configuration
        layout = QVBoxLayout()
        self.editor = QPlainTextEdit()

        # Setup default font
        font = QFont(config['default_font']['font_name'],
                     config['default_font']['size'])
        self.editor.setFont(font)

        # Path of the currently open file
        self.path = None
        layout.addWidget(self.editor)
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

        self.statistics_file = "training_statistics.json"
        self.load_statistics()

        self.status = QStatusBar()
        self.setStatusBar(self.status)

        self.error_label = QLabel()
        self.status.addPermanentWidget(self.error_label)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_word_count)
        self.timer.start(5000)  # Обновлять каждую секунду (1000 мс)
        # edit toolbar
        file_toolbar = QToolBar("File")
        file_toolbar.setIconSize(QSize(14, 14))
        self.addToolBar(file_toolbar)
        file_menu = self.menuBar().addMenu("&File")

        # Set standard file actions
        set_open_file_action(file_menu, file_toolbar,
                             config['shortcuts']['open'], self)
        set_save_file_action(file_menu, file_toolbar,
                             config['shortcuts']['save'], self)
        set_saveas_file_action(file_menu, file_toolbar, self)
        set_print_action(file_menu, file_toolbar,
                         config['shortcuts']['print'], self)

        # Set standard operations
        edit_toolbar = QToolBar("Edit")
        edit_toolbar.setIconSize(QSize(16, 16))
        self.addToolBar(edit_toolbar)
        edit_menu = self.menuBar().addMenu("&Edit")

        set_undo_action(edit_menu, edit_toolbar, self)
        set_redo_action(edit_menu, edit_toolbar, self)

        edit_menu.addSeparator()

        self.current_errors = 0
        set_cut_action(edit_toolbar, edit_menu, self)
        set_copy_action(edit_toolbar, edit_menu, self)
        set_paste_action(edit_toolbar, edit_menu, self)
        set_select_action(edit_menu, self)
        set_wrap_action(edit_menu, self)
        set_find_action(edit_menu, config['shortcuts']['find'], self)
        set_start_training_action(edit_toolbar, self)
        set_stop_training_action(edit_toolbar, self)
        set_wiki_start_training_action(edit_toolbar, self)
        set_show_statistics_action(edit_toolbar, self)
        set_clear_statistics_action(edit_toolbar, self)

        view_menu = self.menuBar().addMenu("&View")
        word_count_action = QAction("Word Count", self)
        word_count_action.triggered.connect(self.update_word_count)
        view_menu.addAction(word_count_action)


        self.editor.textChanged.connect(self.update_word_count)

        self.training_label = QLabel("")
        layout.addWidget(self.training_label)

        self.update_title()
        self.show()
        config_file.close()

    def load_statistics(self):
        # Check if the statistics file exists and is not empty
        if Path(self.statistics_file).is_file():
            with open(self.statistics_file, 'r') as file:
                try:
                    self.statistics = json.load(file)
                except json.JSONDecodeError:
                    # If there is a decode error, assume the file is empty or corrupted and start fresh
                    self.statistics = []
        else:
            # If the file does not exist, start with an empty list
            self.statistics = []

    def save_statistics(self):
        # Сохранение статистики в файл
        with open(self.statistics_file, 'w') as file:
            json.dump(self.statistics, file, indent=4)

    def update_statistics(self, completed, words_typed, elapsed_time, error_count):
        # Обновление статистики после каждой тренировки
        self.statistics.append({
            "completed": completed,
            "words_typed": words_typed,
            "elapsed_time": elapsed_time,
            "error_count": error_count,
            "timestamp": time.time()
        })
        self.save_statistics()

    def show_statistics(self):
        self.load_statistics()

        if not self.statistics:
            QMessageBox.information(self, "Статистика", "Статистика пока что пуста.")
            return

        # Собираем информацию из статистики для использования в графике
        total_sessions = len(self.statistics)
        words_per_session = [session['words_typed'] for session in self.statistics]
        time_per_session = [session['elapsed_time'] for session in self.statistics]
        errors_per_session = [session['error_count'] for session in self.statistics]


        # Создаем диалоговое окно для графика
        dialog = QDialog(self)
        dialog.setWindowTitle("Статистика тренировок")
        layout = QVBoxLayout()

        # Создаем фигуру Matplotlib и добавляем на нее график
        figure = plt.figure()
        canvas = FigureCanvas(figure)
        ax = figure.add_subplot(111)

        # Генерируем данные для графика
        sessions = range(1, total_sessions + 1)

        # Рисуем графики
        ax.plot(sessions, words_per_session, label='Words Typed')
        ax.plot(sessions, time_per_session, label='Time Elapsed (sec)')
        ax.plot(sessions, errors_per_session, label='Errors Made')
        ax.set_xlabel('Session Number')
        ax.set_title('Training Statistics')
        ax.legend()

        # Добавляем график в layout диалогового окна
        layout.addWidget(canvas)
        dialog.setLayout(layout)

        total_words_typed = sum(session['words_typed'] for session in self.statistics)
        total_time_elapsed = sum(session['elapsed_time'] for session in self.statistics)
        total_errors_made = sum(session['error_count'] for session in self.statistics)
        completed_sessions = sum(1 for session in self.statistics if session['completed'])

        # Форматируем текст с общим количеством для каждой метрики
        summary_text = (f"Всего сессий: {total_sessions}\n"
                        f"Сессий завершено: {completed_sessions}\n"
                        f"Всего напечатано слов: {total_words_typed}\n"
                        f"Общее затраченное время: {total_time_elapsed} секунд\n"
                        f"Всего ошибок: {total_errors_made}")

        # Создаем QLabel и устанавливаем текст суммарной статистики
        summary_label = QLabel(summary_text)

        # Добавляем QLabel и FigureCanvas в layout
        layout.addWidget(canvas)
        layout.addWidget(summary_label)  # Добавляем QLabel под график
        dialog.setLayout(layout)

        # Показываем диалоговое окно с графиком и статистикой
        dialog.exec_()

    def clear_statistics(self):
        # Этот метод будет очищать статистику, предупреждая пользователя перед выполнением действия
        reply = QMessageBox.question(self, 'Подтвердите действие',
                                     "Вы уверены, что хотите удалить всю статистику?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            # Здесь мы очищаем файл статистики
            with open("training_statistics.json", "w") as file:
                file.write("[]")  # Пишем пустой список в файл, очищая его
            self.statistics = []  # Очищаем статистику и в самом приложении
            QMessageBox.information(self, "Статистика", "Статистика успешно удалена.")

    def reset_training(self):
        original_text = self.sample_text  # Сохраняем изначальный текст перед очисткой
        self.editor.blockSignals(True)  # Отключение сигналов перед очисткой

        # Сброс форматирования текста перед очисткой редактора
        cursor = self.editor.textCursor()
        cursor.select(QTextCursor.Document)  # Выбираем весь текст
        format_reset = QTextCharFormat()
        format_reset.setBackground(QBrush(Qt.transparent))  # Удаление фона
        cursor.mergeCharFormat(format_reset)
        cursor.clearSelection()

        self.editor.clear()
        self.training_label.clear()

        # Возвращаем изначально введённый текст обратно в редактор
        self.editor.setPlainText(original_text)

        self.editor.blockSignals(False)  # Включение сигналов после очистки

        # Отключаем подключение события изменения текста
        try:
            self.editor.textChanged.disconnect(self.track_input)
        except TypeError:
            # Если событие не было подключено, игнорируем ошибку
            pass

    def stop_training(self, completed=False):
        if not self.training_active:
            QMessageBox.warning(self, "Тренировка не начата", "Начните тренировку перед её остановкой.")
            return

        elapsed_time = int(time.time() - self.start_time)
        elapsed_minutes = elapsed_time // 60
        elapsed_seconds = elapsed_time % 60
        words_typed = len(self.editor.toPlainText().split())
        words_per_minute = (words_typed / elapsed_time) * 60 if elapsed_time > 0 else 0

        self.training_active = False
        self.reset_training()

        self.update_statistics(completed, words_typed, elapsed_time, self.error_count)

        if completed:
            QMessageBox.information(
                self,
                "Тренировка завершена",
                f"Вы успешно завершили тренировку!\n"
                f"Слов: {words_typed}, Время: {elapsed_minutes} мин. {elapsed_seconds} сек., \n"
                f"Слов в минуту: {words_per_minute:.2f}\n"
                f"Ошибок: {self.error_count}"
            )
        else:
            QMessageBox.information(
                self,
                "Тренировка остановлена",
                f"Тренировка была остановлена.\n"
                f"Слов: {words_typed}, Время: {elapsed_minutes} мин. {elapsed_seconds} сек., \n"
                f"Слов в минуту: {words_per_minute:.2f}\n"
                f"Ошибок: {self.error_count}"
            )

        self.update_word_count()

    def update_word_count(self):
        if self.training_active and hasattr(self, 'sample_text') and self.sample_text:
            words_left = len(self.sample_text.split()) - len(self.editor.toPlainText().split())
            elapsed_time = int(time.time() - self.start_time)
            elapsed_minutes = elapsed_time // 60
            elapsed_seconds = elapsed_time % 60
            self.error_label.setText(
                f"<span style='color:red;'>Errors: {self.error_count}</span>")  # Установить текст с ошибками
            self.status.showMessage(f"Words left: {words_left} | Time: {elapsed_minutes}:{elapsed_seconds:02d}")
        else:
            # Если тренировка не активна, то мы просто показываем текущий счетчик слов
            current_word_count = len(self.editor.toPlainText().split())
            self.status.showMessage(f"Word Count: {current_word_count}")
            self.error_label.clear()  # Очистить текст ошибок, когда тренировка не активнау

    def update_training_label(self, user_input, max_words_per_line=10):
        html_text = "<pre>"
        word_count = 0
        for i, char in enumerate(self.sample_text):
            # Wrap to next line after a certain number of words
            if char == ' ':
                word_count += 1
                if word_count >= max_words_per_line:
                    html_text += '<br>'
                    word_count = 0

            if i >= len(user_input):
                # If this is the next character to input, highlight it with transparent yellow
                if i == len(user_input):
                    color = "background-color: rgba(255, 255, 0, 0.5);"  # 50% transparent yellow
                else:
                    # Transparent gray for unreached spaces
                    color = "background-color: rgba(128, 128, 128, 0.3);" if char == ' ' else ""  # 30% transparent gray

                char_html = char.replace(' ', '&nbsp;').replace('\n', '<br>')
                html_text += f"<span style='{color}'>{char_html}</span>"
            elif user_input[i] == char:
                # Green color for correctly entered characters
                span_char = char.replace(' ', '&nbsp;').replace('\n', '<br>')
                html_text += f"<span style='background-color: green;'>{span_char}</span>"
            else:
                # Red color for incorrectly entered characters
                span_char = char.replace(' ', '&nbsp;').replace('\n', '<br>')
                html_text += f"<span style='background-color: red;'>{span_char}</span>"
        html_text += "</pre>"
        self.training_label.setText(html_text)

    def start_training(self):
        text = self.editor.toPlainText().strip()  # Получение и очистка введенного текста
        if not text:
            # Если текст не введен, показываем сообщение об ошибке
            QMessageBox.warning(self, "Ошибка", "Введите текст для тренировки перед началом.")
            return
        elif len(text) > 1500:  # Здесь вы можете установить желаемое ограничение
            QMessageBox.warning(self, "Слишком много символов",
                                "Текст для тренировки слишком длинный. Введите меньше символов.")
            return

        # Если все проверки пройдены, начинаем тренировку
        self.sample_text = text
        self.editor.clear()  # Очистка редактора перед началом тренировки
        self.update_training_label("")  # Инициализация обучающего лейбла
        self.start_time = time.time()  # Установка времени начала тренировки
        self.error_count = 0  # Сброс счетчика ошибок
        self.editor.textChanged.connect(self.track_input)  # Подключение события изменения текста
        self.training_active = True  # Устанавливаем флаг активности тренировки
        self.update_word_count()  # Обновляем счетчик слов

    def track_input(self):

        user_input = self.editor.toPlainText()
        self.update_training_label(user_input)

        # Считаем ошибки в текущем вводе пользователя
        new_errors = 0  # Подсчет новых ошибок за этот ввод

        # Сравниваем введенный текст с образцом
        for i, (user_char, correct_char) in enumerate(zip(user_input, self.sample_text)):
            if user_char != correct_char:
                new_errors += 1

        # Обновляем общее количество ошибок только если были новые ошибки
        if new_errors > self.current_errors:
            self.error_count += new_errors - self.current_errors

        # Сохраняем текущее количество ошибок для следующего сравнения
        self.current_errors = new_errors

        # Обновляем отображение ошибок и тренировочный лейбл
        self.update_training_label(user_input)

        # Если весь текст введен правильно, показываем сообщение и сбрасываем состояние
        if user_input == self.sample_text:
            self.stop_training(completed=True)
            return

        user_input = self.editor.toPlainText()
        self.update_training_label(user_input)
        format_correct = QTextCharFormat()
        format_correct.setBackground(QBrush(QColor("green")))
        format_incorrect = QTextCharFormat()
        format_incorrect.setBackground(QBrush(QColor("red")))

        cursor = self.editor.textCursor()
        self.editor.blockSignals(True)


        # Возвращаем курсор на начало документа для форматирования
        cursor.setPosition(0)

        for i, char in enumerate(user_input):
            cursor.movePosition(QTextCursor.Right, QTextCursor.KeepAnchor)
            if i < len(self.sample_text) and char == self.sample_text[i]:
                cursor.mergeCharFormat(format_correct)
            else:
                cursor.mergeCharFormat(format_incorrect)
            cursor.clearSelection()

        # Возвращаем курсор на позицию после последнего введенного символа
        cursor.setPosition(len(user_input))
        self.editor.setTextCursor(cursor)
        self.editor.blockSignals(False)

    def get_wiki_text(self, max_length, lang='en'):
        assert isinstance(lang, str), "lang must be a string"
        wikipedia.set_lang(lang)
        """
        Fetch a random summary from a Wikipedia Featured Article.

        Args:
        - max_length (int): The maximum length of the summary in words.
        - lang (str): The language edition of Wikipedia to search.

        Returns:
        - text (str): The summary text from Wikipedia.
        - url (str): The URL of the Wikipedia page.
        """
        wikipedia.set_lang(lang)
        featured_articles = wikipedia.page("Wikipedia:Featured articles").links

        while True:
            article_title = random.choice(featured_articles)
            print(f"Selected article title: {article_title} (type: {type(article_title)})")  # Debug print
            try:
                page = wikipedia.page(article_title)
                text = page.summary

                if len(text.split()) <= max_length:
                    return text, page.url
            except wikipedia.exceptions.DisambiguationError as e:
                # This error occurs if the page is a disambiguation page,
                # not an article. We'll just skip it and try another.
                continue
            except wikipedia.exceptions.PageError as e:
                # This error occurs if the page does not exist,
                # we'll skip this as well.
                continue

    def start_wiki_training(self):
        try:
            max_length = 200  # Пример ограничения длины текста
            text, url = self.get_wiki_text(max_length)
            self.editor.setPlainText(text)  # Вставляем текст в редактор
            self.status.showMessage(f"Loaded text from: {url}")  # Показываем URL в статус баре
        except Exception as e:
            traceback.print_exc()  # This will print the stack trace
            QMessageBox.warning(self, "Ошибка", f"Не удалось загрузить текст из Википедии: {e}")

    def show_error(self, s):
        errorDialog = QMessageBox(self)
        errorDialog.addButton("Cancel", QMessageBox.ActionRole)

        errorDialog.setWindowTitle("Find")
        errorDialog.setText("Not Found {:s}.".format(s))
        errorDialog.setIcon(QMessageBox.Critical)
        errorDialog.exec_()

    def toggle_theme_default(self, theme):
        try:
            if theme == 'dark':
                app = QApplication.instance()
                app.setStyleSheet(qdarktheme.load_stylesheet(theme))
        except Exception as e:
            self.show_error(self, e)

    def toggle_theme_custom(self, path):
        try:
            app = QApplication.instance()
            file = QFile(path)
            file.open(QFile.ReadOnly | QFile.Text)
            stream = QTextStream(file)
            app.setStyleSheet(stream.readAll())
        except Exception as e:
            self.show_error(e)

    def open_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open file", "", "Text documents (*.txt);All files (*.*)")

        if path:
            try:
                with open(path, 'rU') as f:
                    text = f.read()

            except Exception as e:
                self.show_error(str(e))

            else:
                self.path = path
                self.editor.setPlainText(text)
                self.update_title()

    def save_file(self):
        if self.path is None:
            # If we do not have a path, we need to use Save As.
            return self.saveas_file()

        self._save_to_path(self.path)

    def saveas_file(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save file", "", "Text documents (*.txt);All files (*.*)")

        if not path:
            # If dialog is cancelled, will return ''
            return

        self._save_to_path(path)

    def _save_to_path(self, path):
        text = self.editor.toPlainText()
        try:
            with open(path, 'w') as f:
                f.write(text)

        except Exception as e:
            self.show_error(str(e))

        else:
            self.path = path
            self.update_title()

    def print_file(self):
        dlg = QPrintDialog()
        if dlg.exec_():
            self.editor.print_(dlg.printer())

    def update_title(self):
        self.setWindowTitle(
            "{:s} - pyQuill".format(os.path.basename(self.path) if self.path else "Untitled"))

    def edit_toggle_wrap(self):
        self.editor.setLineWrapMode(
            1 if self.editor.lineWrapMode() == 0 else 0)

    def Find_word(self):
        self.findDialog = QDialog(self)

        findLabel = QLabel("Find Word:")
        self.lineEdit = QLineEdit()
        self.lineEdit.setText("")
        findLabel.setBuddy(self.lineEdit)

        replaceLabel = QLabel("Replace Word:")
        self.lineReplace = QLineEdit()
        self.lineReplace.setText("")
        replaceLabel.setBuddy(self.lineReplace)

        self.findButton = QPushButton("Find Next")
        self.findButton.setDefault(True)
        self.findButton.clicked.connect(self.searchText)

        self.replaceButton = QPushButton("Replace Next")
        self.replaceButton.setDefault(False)
        self.replaceButton.clicked.connect(self.replaceText)

        buttonBox = QDialogButtonBox(Qt.Vertical)
        buttonBox.addButton(
            self.findButton, QDialogButtonBox.ActionRole)
        buttonBox.addButton(
            self.replaceButton, QDialogButtonBox.ActionRole)

        topLeftLayout = QVBoxLayout()
        topLeftLayout.addWidget(findLabel)
        topLeftLayout.addWidget(self.lineEdit)
        topLeftLayout.addWidget(replaceLabel)
        topLeftLayout.addWidget(self.lineReplace)

        leftLayout = QVBoxLayout()
        leftLayout.addLayout(topLeftLayout)

        mainLayout = QGridLayout()
        mainLayout.setSizeConstraint(QLayout.SetFixedSize)
        mainLayout.addLayout(leftLayout, 0, 0)
        mainLayout.addWidget(buttonBox, 0, 1)
        mainLayout.setRowStretch(2, 1)
        self.findDialog.setLayout(mainLayout)

        self.findDialog.setWindowTitle("Find")
        self.findDialog.show()

    def searchText(self, replace=False):
        cursor = self.editor.textCursor()
        findIndex = cursor.anchor()
        text = self.lineEdit.text()
        content = self.editor.toPlainText()
        length = len(text)
        index = content.find(text, findIndex)

        if -1 == index:
            self.show_error("Not Found {:s}.".format(text))
        else:
            start = index

            cursor = self.editor.textCursor()
            cursor.clearSelection()
            cursor.movePosition(QTextCursor.Start,
                                QTextCursor.MoveAnchor)
            cursor.movePosition(QTextCursor.Right,
                                QTextCursor.MoveAnchor, start + length)
            cursor.movePosition(QTextCursor.Left,
                                QTextCursor.KeepAnchor, length)
            cursor.selectedText()
            if replace:
                cursor.insertText(self.lineReplace.text())
            self.editor.setTextCursor(cursor)

    def replaceText(self):
        self.searchText(True)
